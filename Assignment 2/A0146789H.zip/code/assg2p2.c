#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

#define NUMELTS 16384

// IMPORTANT: Compile using "gcc assg2p2.c .lm -o assg2p2".
// The "-lm" is important as it brings in the Math library.
// Implements the naive primality test.
// Returns TRUE if n is a prime number

int prime(int n)
{
    int ret=1, i;
    for(i=2; i<=(int) sqrt(n) && ret; i++)
        ret=n % i;
    return ret;
}

int main()
{
    int data[NUMELTS];
    int fd[2];
    int parent_count = 0; // Necessarily less than the largest possible int.
    int child_count = 0;

    // Making the pipe
    pipe(fd);

    // Create the random number list.
    srand(time(NULL));
    for(int i = 0; i<NUMELTS; i++)
        data[i]=(int) (((double) rand() / (double) RAND_MAX) * 10000);

    // Now create a parent and child process.
    if (fork()) {
        //PARENT:
        // Close the write fd
        close(fd[1]);

        // Check the 0 to 8191 sub-list
        for (int i = 0; i < 8192; i++) {
            if (prime(data[i])) {
                ++parent_count;
            }
        }

        // Then wait for the prime number count from the child.
        read(fd[0], &child_count, sizeof(child_count));

        // Parent should then print out the number of primes
        // found by it, number of primes found by the child,
        // And the total number of primes found.
        printf("Parent Count: %d\n", parent_count);
        printf(" Child Count: %d\n", child_count);
        printf(" Total Count: %d\n", parent_count + child_count);
    }
    else {
        // CHILD:
        // Close the read fd
        close(fd[0]);

        // Check the 8192 to 16383 sub-list.
        for (int i = 8192; i < NUMELTS; i++) {
            if (prime(data[i])) {
                ++child_count;
            }
        }

        // Send # of primes found to the parent.
        write(fd[1], &child_count, sizeof(child_count));
    }
}
